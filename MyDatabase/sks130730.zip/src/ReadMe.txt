Please follow the below steps to compile and run the JAVA program.

1)Compilation -  javac -cp \Externaljar\*; MyDatabase.java

2)Run  -         java -cp \Externaljar\*; mydatabase.MyDatabase  

The source code is present in the mydatabase folder. 
The externaljar folder contains the jar used for this project.